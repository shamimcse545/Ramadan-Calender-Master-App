package com.example.ramadanmubarak.BackendClass;

import java.util.ArrayList;

public class DataHolder {

    public static ArrayList<Ramadan>ramadanArrayListRahmat = null;

    public static ArrayList<Ramadan>ramadanArrayListMagrifat = null;

    public static ArrayList<Ramadan>ramadanArrayListNajat = null;

}
