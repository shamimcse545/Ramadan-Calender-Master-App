package com.example.ramadanmubarak.BackendClass;

public class Ramadan {
    String RamadanDay;
    String Date;
    String Day;
    String Sehar;
    String Iftar;

    public String getRamadanDay() {
        return RamadanDay;
    }

    public void setRamadanDay(String ramadanDay) {
        RamadanDay = ramadanDay;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getDay() {
        return Day;
    }

    public void setDay(String day) {
        Day = day;
    }

    public String getSehar() {
        return Sehar;
    }

    public void setSehar(String sehar) {
        Sehar = sehar;
    }

    public String getIftar() {
        return Iftar;
    }

    public void setIftar(String iftar) {
        Iftar = iftar;
    }
}
