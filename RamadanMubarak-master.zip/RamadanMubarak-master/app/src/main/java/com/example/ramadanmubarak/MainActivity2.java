package com.example.ramadanmubarak;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


public class MainActivity2 extends AppCompatActivity {

}

